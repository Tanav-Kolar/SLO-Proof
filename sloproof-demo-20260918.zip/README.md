# Forge the Future Hackathon

Private team repository for the Elastic Forge the Future Hackathon.

**Use `main` as the canonical demo branch.** See [the branch review](docs/BRANCH_REVIEW.md) for integrated work and deferred experiments.

**Present the decision challenge:** open [`demo/index.html`](demo/index.html)
and follow the [four-minute showcase script](docs/SHOWCASE_SCRIPT.md). Ask judges
“Would you ship this recovery?”, then reveal the actual FAILED, PROVED and
INCONCLUSIVE results. The portable walkthrough includes saved native Elastic
reviews and inspectable evidence; it needs no credentials.

For the current demo, start with [the operator runbook](docs/DEMO_RUNBOOK.md),
[the integrated Elastic agents and workflow](elastic/README.md),
[the two-hour finish plan](docs/TWO_HOUR_FINISH.md), and
[the control-plane implementation status](src/control/README.md). Earlier
architecture notes predate the verifier and in-cluster load-generator work.

## Start here

1. Copy `.env.example` to `.env` and add your keys locally.
2. Put application code in `src/`.
3. Put notes, architecture, and screenshots in `docs/`.
4. Fill in `SUBMISSION.md` as you build. Judges read that file first.

See the [SLOProof demo and service reuse plan](docs/DEMO_AND_SERVICE_REUSE.md) for the proposed checkout demo, metrics, recovery criteria, and extension to other APIs.

See the [service architecture](docs/SERVICE_ARCHITECTURE.md) for the verified capability baseline, plane-by-plane design, credential boundaries, and cluster-isolation requirement.

See the [checkout service spec](docs/CHECKOUT_SERVICE_SPEC.md) for the service's endpoints, fault profiles, configuration layers, and the deploy and demo scripts.

See the [reasoning plane](src/agents/README.md) for the three advisory agents, how to run them, and why they call Bedrock directly instead of going through Agent Builder.

## Credentials

Do not commit AWS codes, API keys, or connection strings, even though this repository is private. Keep secrets in `.env`.

## Submit

Keep `SUBMISSION.md` current through the event. Use a pull request if more than one person is changing the same files.
